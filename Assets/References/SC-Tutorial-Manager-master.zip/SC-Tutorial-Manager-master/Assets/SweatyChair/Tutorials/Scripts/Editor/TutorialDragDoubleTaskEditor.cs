﻿using UnityEngine;
using UnityEditor;
using System.Collections;

namespace SweatyChair
{

	[System.Serializable]
	[CustomEditor(typeof(TutorialDragDoubleTaskEditor), true)]
	public class TutorialDragDoubleTaskEditor : TutorialDragTaskEditor
	{
	}

}